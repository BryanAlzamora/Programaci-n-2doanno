<script setup>
import Controlador from './components/Controlador.vue';
</script>

<template>
  <Controlador />
</template>
