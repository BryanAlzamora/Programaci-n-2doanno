<?php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/UserModel.php';

class LoginController extends BaseController {
    
    public function index() {
        $listaTorneos=TorneoModel::getAll();
        $tituloHeader=BaseController::getIdioma();

        $this->render('index.view',[
            'listaTorneos' => $listaTorneos,
            'tituloHeader' => $tituloHeader
        ]);
    }
    

    
}