<?php
require_once __DIR__ . '/../models/UserModel.php';

class BaseController {
    
    protected function render($view, $data = []) {
        // Extraer variables para la vista
        extract($data, EXTR_SKIP);
        

        // Incluir layout con la vista
        require __DIR__ . "/../views/layout/header.php";
        require __DIR__ . "/../views/{$view}.php";
        require __DIR__ . "/../views/layout/footer.php";
    }
    
    protected function redirect($url) {
        header("Location: {$url}");
        exit;
    }

    // Funciones que pueden servir de ayuda para lograr algunas funcionalidades
    protected function currentUser() {
        
    }
    
    protected function isLoggedIn() {
        $user=$_POST['user'];
        $password=$_POST['password'];
        
        $validar=UserModel::verifyPassword($user, $password);
    
        if($validar){
            $nombre=UserModel::usuarioLogueado($validar);
            $this->render('index.php?controller=');
        }
    }

    protected function getIdioma() {
        $idioma=$_POST['idioma'];
        if($idioma){
            setcookie('idioma',$idioma,time()+ 7*24*60*60);
        }
       $this->redirect('index.php?controller=TorneoController&accion=index');

    }
}