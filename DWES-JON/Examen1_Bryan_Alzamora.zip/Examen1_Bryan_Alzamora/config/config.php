<?php

// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'dwes_torneos');
define('DB_USER', 'root');
define('DB_PASS', '');