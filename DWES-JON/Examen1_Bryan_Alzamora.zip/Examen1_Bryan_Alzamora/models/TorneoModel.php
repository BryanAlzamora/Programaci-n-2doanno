<?php
require_once __DIR__ . '/Database.php';

class TorneoModel {
    
    public static function getAll() {
        $db = Database::getConnection();
        $sql= "SELECT * FROM torneos";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public static function getById($id) {
        $db = Database::getConnection();
        $sql= "SELECT id,titulo,juego,fecha,plazas_totales as plazas,estado,descripcion FROM torneos
                WHERE id=:id";
        $stmt = $db->prepare($sql);
        $stmt->execute(['id'=>$id]);
        return $stmt->fetch();
    }
    
    public static function create($datos) {
         $db = Database::getConnection();
        $sql= "INSERT INTO torneros(titulo,juego,descripcion,fecha,plazas_totales) 
                VALUES(:titulo,:juego,:descripcion,:fecha,:plazas,)";
        $stmt = $db->prepare($sql);
         $stmt->execute([
            'titulo' => $datos['titulo'],
            'juego' => $datos['juego'],
            'descripcion' => $datos['descripcion'],
            'fecha' => $datos['fecha'],
            'plazas' => $datos['plazas']
        ]);
    }

    public static function modificarEstado($id,$estado){
        $db = Database::getConnection();
        $sql= "UPDATE torneos SET estado = :estado WHERE id=:id";
        $stmt = $db->prepare($sql);
        
        return $stmt->execute([
            'id'=>$id,
            'estado'=>$estado
        ]);
    }
    public static function deleteById($id) {
        $db = Database::getConnection();
        $sql= "DELETE FROM torneos WHERE id=:id";
        $stmt = $db->prepare($sql);
        
        return $stmt->execute([
            'id'=>$id
        ]);
    }
    
    public static function deleteAll() {
        $db = Database::getConnection();
        $sql= "DELETE FROM torneos";
        $stmt = $db->prepare($sql);
        
        return $stmt->execute();
    }
    
}