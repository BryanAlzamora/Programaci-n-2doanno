<?php
require_once __DIR__ . '../layout/header.php';
?>
    <header>
        <div class="container">
            <h1>
                <!-- Aquí se deberá mostrar el título según el idioma en cookie -->
                <a href="index.php">Torneos</a>
            </h1>
            <nav>
                <!-- Insertar aquí una lista con dos elementos en función de si el usuario está autenticado -->
            </nav>
        </div>
    </header>
    <main class="container">
        <div>
            <div>
                <h2>Torneos disponibles</h2>
            <!-- Insertar aquí el botón para crear un torneo -->
            </div>

            <!-- Insertar aquí la tabla con el listado de torneos -->
            <div clas="listadoTorneosCss">
                <ul name="listaTorneos">
                    <?php foreach($listaTorneos as $torneo) : ?>
                        <li>Nombre:<?=$torneo['titulo'] ?></li>
                        <li>juego:<?=$torneo['juego'] ?></li>
                        <li>fecha:<?=$torneo['fecha'] ?></li>
                        <li>plazas:<?=$torneo['plazas_totales'] ?></li>
                        <li>estado:<?=$torneo['estado'] ?></li>
                        <li>Acciones: <a href="index.php?controller=TorneoController&accion=getById&id=<?= $torneo['id']?>">Ver mas</a>
                    <a href="index.php?controller=TorneoController&accion=deleteById&id=<?= $torneo['id']?>">eliminar</a></li>
                        --------------------------------------------
                        
                    <?php endforeach;?>
                </ul>
            </div>

            
        </div>
                    -------AQUI CREO TORNEO--------
        <div>
           <h3> Crear nuevo torneo</h3>
            <form method="POST" action="index.php?controller=TorneoController&accion=crearTorneo">
            <label>Titulo </label>
            <input type="text" name="titulo">
            <label>Juego </label>
            <input type="text" name="juego">
            <label>Descripcion </label>
            <input type="text" name="descripcion">
            <label>fecha </label>
            <input type="text" name="fecha" placeholder="dd/mm/aaaa">
            <label>Plazas totales </label>
            <input type="text" name="plazas">
            
            
            <input type="submit" value="Crear">
            </form>
            
        </div>



        
    </main>

<?php
    require_once __DIR__ . '../layout/footer.php';
?>