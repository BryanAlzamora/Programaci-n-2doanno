<footer>
    <div class="container">
        <p>&copy; Torneos - 2025</p>
        <!-- Insertar aquí el formulario de cambio de idioma-->
         <form method="index.php?controller=BaseController&accion=getIdioma" action="POST">
            <select name="idioma">
                <option value="castellano">Castellano</option>
                <option value="euskera">Euskera</option>
                <input type="submit" value="Cambiar idioma">
            </select>
        </form>
    </div>
</footer>
</body>
</html>
